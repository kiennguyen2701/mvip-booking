import Link from "next/link";
import { cookies } from "next/headers";

import { createClient } from "@/lib/supabase/server";
import { LogoutButton } from "@/components/logout-button";
import HeaderMobileMenu from "@/components/header-mobile-menu";
import CustomerHeaderMenu from "@/components/customer-header-menu";
import SupplierHeaderMenu from "@/components/supplier-header-menu";

function getDashboardHref(role: string | null) {
  if (role === "admin") return "/dashboard/admin";
  if (role === "supplier") return "/dashboard/supplier";
  if (role === "agent") return "/dashboard/agent";
  if (role === "customer") return "/dashboard/customer";

  return "/login";
}

function hasSupabaseAuthCookie(
  cookieList: Awaited<ReturnType<typeof cookies>>,
) {
  return cookieList
    .getAll()
    .some(
      (cookie) =>
        cookie.name.startsWith("sb-") &&
        (cookie.name.includes("auth-token") ||
          cookie.name.includes("access-token") ||
          cookie.name.includes("refresh-token")),
    );
}

export default async function Header() {
  const cookieStore = await cookies();
  const hasAuthCookie = hasSupabaseAuthCookie(cookieStore);

  let user = null;
  let role: string | null = null;

  if (hasAuthCookie) {
    const supabase = await createClient();

    const {
      data: { user: authUser },
    } = await supabase.auth.getUser();

    user = authUser;

    if (user) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .maybeSingle();

      role = profile?.role || user.user_metadata?.role || null;
    }
  }

  const dashboardHref = getDashboardHref(role);
  const isCustomer = role === "customer";
  const isSupplier = role === "supplier";

  return (
    <header className="sticky top-0 z-[9999] border-b border-white/10 bg-[#080704]/95 text-white backdrop-blur-xl">
      <div className="mx-auto flex h-[92px] w-full max-w-7xl items-center justify-between gap-4 px-4 md:h-[96px] md:px-6">
        <Link
          href={dashboardHref}
          prefetch={false}
          className="flex min-w-0 items-center gap-3"
        >
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-300 to-yellow-600 text-xl text-slate-950 shadow-xl shadow-amber-950/20">
            ♛
          </div>

          <div className="min-w-0">
            <p className="truncate text-xl font-black leading-tight text-white">
              Mvip Booking
            </p>

            <p className="truncate text-xs font-semibold text-slate-500">
              Premium booking platform
            </p>
          </div>
        </Link>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <>
              {isCustomer ? (
                <CustomerHeaderMenu />
              ) : isSupplier ? (
                <SupplierHeaderMenu />
              ) : (
                <LogoutButton />
              )}
            </>
          ) : (
            <Link
              href="/login?mode=register"
              prefetch={false}
              className="rounded-2xl bg-amber-300 px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-amber-200"
            >
              Register
            </Link>
          )}
        </div>

        {user && (
          <div className="md:hidden">
            <HeaderMobileMenu isLoggedIn={!!user} role={role} />
          </div>
        )}
      </div>
    </header>
  );
}